/*
w tym skrypcie jest wykorzystywana wiedza z laboratoriów
    1 - table, form, fieldset
    4 - walidacja za pomoc html
    6 - javascript
    7 - SPA
    9 - jQuery
*/

// akcje do wykonywania po załadowaniu strony
$(document).ready(function () {

    $('#records').click(function () {                                                                   // L7(SPA) funkcja do załadowania formularu "Własne rekordy" po kliknięciu na odpowiedni przycisk (o id records)
        $("#contest").html(                                                                             // L9(jQuery html) wklejanie do elementu o id contest kodu html zawartego w nawiasah
            '<fieldset id="fieldset_records">' +                                                        // L1(fieldset) umieczszamy formularz w fieldset dla dodatkowej stylizacji formularzu
            '    <legend>Własne rokordy</legend> ' +                                                    // L1(legend) nazwa fieldset
            '    <table id="t_input">\n' +                                                              // L1(table) początek tabeli
            '        <tbody id="b_input">\n' +                                                          // L1(tbody) początek ciała tabeli
            '            <tr>' +                                                                        // L1(tr) początek wierszu tabeli
            '                <td><label for="name">Nazwa ryby:</label></td>' +                          // L1(td), L2(label) komurka pierwszej kolumny (ma w sobie etykietę pola do wprowadzenia danych)
            '                <td><input type="text" id="name" name="name"></td>' +                      // L1(td,input), komurka drugiej kolumny (ma w sobie pole do wprowadzenia danych)
            '                <td class="error" id="error_name"></td>' +                                 // L1(td, input), L2(class) komurka trzeciej kolumny (ma w sobie pole do wyprowadzeniu komunikatu o błędzie)
            '            </tr>' +                                                                       // L1(tr) koniec wiersza tabeli
            '            <tr>' +                                                                        // L1(tr) początek wierszu tabeli
            '                <td><label for="date">Data połowu:</label></td>' +                         // L1(td), L2(label) komurka pierwszej kolumny (ma w sobie etykietę pola do wprowadzenia danych)
            '                <td><input type="text" id="date" name="date" ' +                           // L1(td,input), komurka drugiej kolumny (ma w sobie pole do wprowadzenia danych)
            '                       title="Wpisz date w formacjie dd.mm.rrrr ' +                        // --, dodatkowe informacje o tym w jakim formacie trzeba wprowadzać dane ->
            '                       (rozdzielacze \'.\', \'-\' lub \'/\')"></td>' +                     // -> są wyświetlane jako tekst podpowiedzi, gdy mysz przesuwa się nad elementem.
            '                <td class="error" id="error_date"></td>' +                                 // L1(td, input), L2(class) komurka trzeciej kolumny (ma w sobie pole do wyprowadzeniu komunikatu o błędzie)
            '            </tr>' +                                                                       // L1(tr) koniec wiersza tabeli
            '            <tr>' +                                                                        // L1(tr) początek wierszu tabeli
            '                <td><label for="telephone">Waga:</label></td>' +                           // L1(td), L2(label) komurka pierwszej kolumny (ma w sobie etykietę pola do wprowadzenia danych)
            '                <td><input type="text" id="weigh" name="weigh"></td>' +                    // L1(td,input), komurka drugiej kolumny (ma w sobie pole do wprowadzenia danych)
            '                <td class="error" id="error_weigh"></td>' +                                // L1(td, input), L2(class) komurka trzeciej kolumny (ma w sobie pole do wyprowadzeniu komunikatu o błędzie)
            '            </tr>' +                                                                       // L1(tr) koniec wiersza tabeli
            '            <tr>' +                                                                        // L1(tr) początek wierszu tabeli
            '                <td><label for="type_of_fishing">Wykorzystany rodzaj wędkarstwa:</label></td>' +   // L1(td), L2(label) komurka pierwszej kolumny (ma w sobie etykietę pola do wprowadzenia danych)
            '                <td><select id="type_of_fishing" name="type_of_fishing">' +                                // L1(td,select), komurka drugiej kolumny (ma w sobie pole do wyboru typu select)
            '                   <option value="wędkarstwo morskie">Wędkarstwo morskie</option>' +                       // L1(option) opcje dostępne do wyboru
            '                   <option value="wędkarstwo muchowe">Wędkarstwo muchowe</option>' +                       // L1(option) opcje dostępne do wyboru
            '                   <option value="wędkarstwo podlodowe">Wędkarstwo podlodowe</option>' +                   // L1(option) opcje dostępne do wyboru
            '                   <option value="wędkarstwo spinningowe">Wędkarstwo spinningowe</option>' +               // L1(option) opcje dostępne do wyboru
            '                   <option value="wędkarstwo spławikowo-gruntowe">Wędkarstwo spławikowo-gruntowe</option>' +// L1(option) opcje dostępne do wyboru
            '                   <option value="trolling">Trolling</option>' +                                           // L1(option) opcje dostępne do wyboru
            '                </select></td>' +                                                          // L1(td, select)  koniec pole do wyboru typu select oraz komurki tabeli
            '                <td class="error" id="error_type_of_fishing"></td>' +                      // L1(td, input), L2(class) komurka trzeciej kolumny (ma w sobie pole do wyprowadzeniu komunikatu o błędzie)
            '            </tr>' +                                                                       // L1(tr) koniec wiersza tabeli
            '            <tr>' +                                                                        // L1(tr) początek wierszu tabeli
            '                <td><label for="destiny">Co się stanie z rybą: </label></td>' +            // L1(td), L2(label) komurka pierwszej kolumny (ma w sobie etykietę pola do wprowadzenia danych)
            '                <td>' +                                                                    // L1(td), komurka drugiej kolumny; ma w sobie
            '                       <input type="radio" name="destiny" id="for_food" value="pójdzie na jedzenie">' +    // L1(radio) pola do wyboru typu radio (są w jednej "grupie" bo mają taką samą nazwę)
            '                           <label for="for_food">Pójdzie na jedzenie</label><br>' +                        // L1(label) oraz ich etykiety
            '                       <input type="radio" name="destiny" id="for_sale" value="sprzedam">' +
            '                           <label for="for_sale">Sprzedam</label><br>' +
            '                       <input type="radio" name="destiny" id="for_friend" value="dam przyjacielowi">' +
            '                           <label for="for_friend">Dam przyjacielowi</label><br>' +
            '                </td>' +                                                                   // L1(td) koniec komurki tabeli
            '                <td class="error" id="error_destiny"></td>' +                              // L1(td, input), L2(class) komurka trzeciej kolumny (ma w sobie pole do wyprowadzeniu komunikatu o błędzie)
            '            </tr>' +                                                                       // L1(tr) koniec wiersza tabeli
            '            <tr>' +                                                                        // L1(tr) początek wierszu tabeli
            '                <td><label for="weather">Jaka była pogoda: </label></td>' +                // L1(td), L2(label) komurka pierwszej kolumny (ma w sobie etykietę pola do wprowadzenia danych)
            '                <td>' +                                                                    // L1(td), komurka drugiej kolumny; ma w sobie
            '                       <input type="checkbox" name="weather" id="sun" value="słonecznie">' +       // L1(checkbox) pola do wyboru typu checkbox (są w jednej "grupie" bo mają taką samą nazwę)
            '                           <label for="sun">Słonecznie</label><br>' +                              // L1(label) oraz ich etykiety
            '                       <input type="checkbox" name="weather" id="cloudy" value="pochmurno">' +
            '                           <label for="cloudy">Pochmurno</label><br>' +
            '                       <input type="checkbox" name="weather" id="rain" value="deszcz">' +
            '                           <label for="rain">Deszcz</label><br>' +
            '                       <input type="checkbox" name="weather" id="wind" value="wiatr">' +
            '                           <label for="wind">Wiatr</label><br>' +
            '                       <input type="checkbox" name="weather" id="other" value="inna">' +
            '                           <label for="other">Inna</label><br>' +
            '                </td>' +                                                                   // L1(td) koniec komurki tabeli
            '                <td class="error" id="error_weather"></td>' +                              // L1(td, input), L2(class) komurka trzeciej kolumny (ma w sobie pole do wyprowadzeniu komunikatu o błędzie)
            '            </tr>' +                                                                       // L1(tr) koniec wiersza tabeli
            '        </tbody>\n' +                                                                      // L1(tbody) koniec ciała tabeli
            '        <tfoot>\n' +                                                                       // L1(tfoot) początek stopki tabeli (ma w sobie przyciski obługujące "baze" rekordów
            '            <tr><td colSpan="3">' +                                                        // L1(tr,td,colspan) wierz z jedną komurką scaloną z trzech kolumn; ma w sobie ->
            '                <div id="green">&nbsp;</div><div id="red">&nbsp;</div>' +                  // L1(div,encje) -> pola do wyprowadzenie komunikatów o poprawności wykonywanych działań
            // (domyślnie mają w sobie encję pustego miesca by zawsze były widoczne i tabela nie zmieniała swojego rozmiaru)
            '            </td></tr>' +                                                                  // L1(tr, td) koniec komurki i wiersza
            '            <tr>' +                                                                                        // L1(tr) początek wierszu stopki tabeli
            '                <td><button class="action_buttons" onclick="choice(0)">Zapisz rekord</button></td>\n' +    // L1(td, button) L2(class) L6(onclick) kolejne przyciski obługujące bazę rekordów ->
            '                <td><button class="action_buttons" onclick="choice(1)">Edytuj rekord</button></td>\n' +    // -> prowadzą do jednej funkcji, w której są zawarte przejścia do ->
            '                <td><button class="action_buttons" onclick="choice(2)">Usuń rekord</button></td>\n' +      // -> poszczególnych funkcji
            '           </tr>' +                                                                                        // L1(tr) koniec wierszu stopki tabeli
            '           <tr>' +                                                                                         // L1(tr) początek wierszu stopki tabeli
            '                <td><button class="action_buttons" onclick="choice(3)">Wyszukaj rekord</button></td>\n' +  // L1(td, button) L2(class) kolejne przyciski obługujące bazę rekordów ->
            '                <td><button class="action_buttons" onclick="choice(4)">Wyswietl rekordy</button></td>\n' + // -> prowadzą do jednej funkcji, w której są zawarte przejścia do ->
            '                <td><button class="action_buttons" onclick="choice(5)">Usuń wszystkie rekordy</button></td>\n' +    // -> poszczególnych funkcji
            '           </tr>' +                                                                                        // L1(tr) koniec wierszu stopki tabeli
            '        </tfoot>\n' +                                                                                      // L1(tfoot) koniec stopki tabeli
            '    </table>\n' +                                                                                          // L1(table) koniec tabeli do wprowadzania danych
            '    <table id="t_output">\n' +                             // L1(table) pocztek tabeli do wyprowadzania danych
            '        <caption><h2>Recordy</h2></caption>\n' +           // L1(caption, h2) nazwa tabeli
            '        <thead><tr>\n' +                                   // L1(thead,tr) nagłówki kolumn tabeli
            '            <th>Nazwa ryby</th>\n' +                       // L1(th) komurki nagłówków kolumn ->
            '            <th>Data połowu</th>\n' +                      // -> odpowiadąjace parametry rekordów
            '            <th>Waga</th>\n' +
            '            <th>Wykorzystany rodzaj wędkarstwa</th>\n' +
            '            <th>Сo się stanie z rybą</th>\n' +
            '            <th>Jaka była pogoda</th>\n' +
            '        </tr></thead>\n' +                                 // L1(thead,tr) koniec części nagłówkowej
            '        <tbody id="b_output"></tbody>\n' +                 // L1(tbody) ciało tabeli. jego zawartością zarządzają przyciski tabeli do wprowadzenia danych
            '    </table>' +                                            // L1(table) koniec tabeli do wyprowadzania danych
            '</fieldset>');                                             // L1(fieldset) koniec fieldset i koniec wprowadzania danych do pola o id "contest"
    });                                                                 // L9(jQuery) koniec obsługi funkcji do załadowania formularu "Własne rekordy" po kliknięciu na odpowiedni przycisk (o id records)
    $('#questionnaire').click(function () {                             // L7(SPA) funkcja do załadowania formularu "Ankieta użytkownika" po kliknięciu na odpowiedni przycisk (o id questionnaire)
        $("#contest").html('<fieldset>' +                               // L9(jQuery html) wklejanie do elementu o id contest kodu html zawartego w nawiasah; umieczszamy formularz w fieldset dla dodatkowej stylizacji formularzu
            '<legend>Ankieta użytkownika</legend> ' +                                                   // L1(legend) nazwa fieldset
            '<form name="questionnaire" id="questionnaire" action="" method="post">' +                  // L1(form) początek formularzu (nie ma działań po submit)
            '    <table id="t_questionnaire">' +                                                        // L1(table) początek tabeli (dla łatwiej stylizacji umieszczamy formularz w tabelę)
            '        <tbody id="b_questionnaire">' +                                                    // L1(tbody) początek ciała tabeli
            '            <tr>' +                                                                        // L1(tr) początek wierszu tabeli
            '                <td><label for="firstname">Imię: *</label></td>' +                         // L1(td), L2(label) komurka pierwszej kolumny (ma w sobie etykietę pola do wprowadzenia danych)
            '                <td><input type="text" id="firstname" name="firstname" ' +                 // L1(td,input), komurka drugiej kolumny (ma w sobie pole do wprowadzenia tekstu)
            '                           pattern="[A-Za-ząęźżśóćńłĄĘŹŻŚÓĆŃŁ\\s]{2,}" ' +                 // L4(pattern) są przyjmowane tylko ciągi od 2 do 20 znaków, złożone z liter alfabetu łacińskiego, znaków polskich oraz spacji
            '                           placeholder="Jan" required></td>' +                             // L5(placeholder, required) podpowiedzi dotyczące formatu wprowadzanych danych; to pole jest wymagane
            '            </tr>' +                                                                       // L1(tr) koniec wiersza tabeli
            '            <tr>' +                                                                        // L1(tr) początek wierszu tabeli
            '                <td><label for="lastname">Nazwisko: *</label></td>' +                      // L1(td), L2(label) komurka pierwszej kolumny (ma w sobie etykietę pola do wprowadzenia danych)
            '                <td><input type="text" id="lastname" name="lastname" ' +                   // L1(td,input), komurka drugiej kolumny (ma w sobie pole do wprowadzenia tekstu)
            '                           pattern="[A-Za-ząęźżśóćńłĄĘŹŻŚÓĆŃŁ-]{2,}" ' +                   // L4(pattern) są przyjmowane tylko ciągi od 2 do 20 znaków, złożone z liter alfabetu łacińskiego, znaków polskich oraz łączników
            '                           placeholder="Kowalski" required></td>' +                        // L4(placeholder) podpowiedzi dotyczące formatu wprowadzanych danych; to pole jest wymagane
            '            </tr>' +                                                                       // L1(tr) koniec wiersza tabeli
            '            <tr>' +                                                                        // L1(tr) początek wierszu tabeli
            '                <td><label for="birthdate">Data urodzenia: *</label></td>' +               // L1(td), L2(label) komurka pierwszej kolumny (ma w sobie etykietę pola do wprowadzenia danych)
            '                <td><input type="date" id="birthday" name="birthday" ' +                   // L1(td,input), komurka drugiej kolumny (ma w sobie pole do wprowadzenia daty)
            '            </tr>' +                                                                       // L1(tr) koniec wiersza tabeli
            '            <tr>' +                                                                        // L1(tr) początek wierszu tabeli
            '                <td><label for="q_telephone">Telefon:</label></td>' +                      // L1(td), L2(label) komurka pierwszej kolumny (ma w sobie etykietę pola do wprowadzenia danych)
            '                <td><input type="tel" id="q_telephone" name="q_telephone" ' +              // L1(td,input), komurka drugiej kolumny (ma w sobie pole do wprowadzenia numeru telefonu)
            '                           pattern="[0-9]{3} [0-9]{3} [0-9]{3}" ' +                        // L4(pattern) są przyjmowane tylko ciągi cyfrowe trzy razy po trzy cyfry ze spacjami między grupami cyfr
            '                           placeholder="123 456 789"></td>' +                              // L4(placeholder) podpowiedzi dotyczące formatu wprowadzanych danych;
            '            </tr>' +                                                                       // L1(tr) koniec wiersza tabeli
            '            <tr>' +                                                                        // L1(tr) początek wierszu tabeli
            '                <td><label for="email">E-mail:</label></td>' +                             // L1(td), L2(label) komurka pierwszej kolumny (ma w sobie etykietę pola do wprowadzenia danych)
            '                <td><input type="email" id="email" name="email" ' +                        // L1(td,input), komurka drugiej kolumny (ma w sobie pole do wprowadzenia adresu poczty elektronicznej)
            '                           pattern="[a-z0-9._%+-]+@[a-z0-9.-]+.[a-z]{2,}$" ' +             // L4(pattern) są przyjmowane tylko ciągi typu znaki@znaki.domena ->
                                                                                                        // -> (znaki, po których następuje znak @, po czym następuje więcej znaków, a następnie „.”; ->
                                                                                                        // -> po znaku „.” dodaj co najmniej 2 litery od a do z
            '            </tr>' +                                                                       // L1(tr) koniec wiersza tabeli
            '            <tr>' +                                                                        // L1(tr) początek wierszu tabeli
            '                <td><label for="experience">Doświadczenie wędkarskie: *</label></td>' +    // L1(td), L2(label) komurka pierwszej kolumny (ma w sobie etykietę pola do wprowadzenia danych)
            '                <td><input type="number" id="experience" name="experience" ' +             // L1(td,input), komurka drugiej kolumny (ma w sobie pole do wprowadzenia liczb ->
            '                           min="0" max="120" step="1"' +                                   // L4(min, max, step)-> naturalnych nieujemnych w zakresie [0,120]
            '                           title="Wpisz ile masz lat dowiadczenia wędkarskiego" ' +        // L4(title) dodatkowe informacje o elemencie, wyświetlane jako tekst podpowiedzi, gdy mysz przesuwa się nad elementem.
            '                           required></td>' +                                               // L4(required) to pole jest wymagane
            '            </tr>' +                                                                       // L1(tr) koniec wiersza tabeli
            '            <tr>' +                                                                                        // L1(tr) początek wierszu tabeli
            '                <td><label for="types_of_fishing">Preferowane rodzaje wędkarstwa:</label></td>' +          // L1(td), L2(label) komurka pierwszej kolumny (ma w sobie etykietę pola do wprowadzenia danych)
            '                <td><select id="types_of_fishing" name="types_of_fishing" required multiple>' +            // L1(td,select), komurka drugiej kolumny (ma w sobie pole do wyboru typu select)
            '                       <option value="wędkarstwo morskie">Wędkarstwo morskie</option>' +                   // L1(option) opcje dostępne do wyboru
            '                       <option value="wędkarstwo muchowe">Wędkarstwo muchowe</option>' +                   // L1(option) opcje dostępne do wyboru
            '                       <option value="wędkarstwo podlodowe">Wędkarstwo podlodowe</option>' +               // L1(option) opcje dostępne do wyboru
            '                       <option value="wędkarstwo spinningowe">Wędkarstwo spinningowe</option>' +           // L1(option) opcje dostępne do wyboru
            '                       <option value="wędkarstwo spławikowo-gruntowe">Wędkarstwo spławikowo-gruntowe</option>' +   // L1(option) opcje dostępne do wyboru
            '                       <option value="trolling">Trolling</option>' +                                       // L1(option) opcje dostępne do wyboru
            '                </select></td>' +                                                                          // L1(td, select)  koniec pole do wyboru typu select oraz komurki tabeli
            '            </tr>' +                                                                                       // L1(tr) koniec wiersza tabeli
            '            <tr>' +                                                                                        // L1(tr) początek wierszu tabeli
            '                <td>W jaki sposób dowiedzieliście o tej stronie:</td>' +                                   // L1(td) komurka pierwszej kolumny (ma w sobie opis pola do wprowadzenia danych)
            '                <td>' +                                                                                    // L1(td), komurka drugiej kolumny; ma w sobie
            '                       <input type="radio" name="source" id="Facebook" value="Facebook">' +                // L1(radio) pola do wyboru typu radio (są w jednej "grupie" bo mają taką samą nazwę)
            '                           <label for="Facebook">Facebook</label><br>' +                                   // L1(label) oraz ich etykiety
            '                       <input type="radio" name="source" id="Instagram" value="Instagram">' +
            '                           <label for="Instagram">Instagram</label><br>' +
            '                       <input type="radio" name="source" id="Reklama" value="reklama">' +
            '                           <label for="Reklama">Reklama</label><br>' +
            '                       <input type="radio" name="source" id="Od przyjaciela" value="od przyjaciela">' +
            '                           <label for="Od przyjaciela">Od przyjaciela</label><br>' +
            '                </td>' +                                                                                   // L1(td) koniec komurki tabeli
            '            </tr>' +                                                                                       // L1(tr) koniec wiersza tabeli
            '            <tr>' +                                                                        // L1(tr) początek wierszu tabeli
            '                <td>Jestem na tej stronie by:</td>' +                                      // L1(td), L2(label) komurka pierwszej kolumny (ma w sobie opis pola do wprowadzenia danych)
            '                <td>' +                                                                    // L1(td), komurka drugiej kolumny; ma w sobie
            '                       <input type="checkbox" name="goals" id="checkbox_1" ' +             // L1(checkbox) pola do wyboru typu checkbox (są w jednej "grupie" bo mają taką samą nazwę)
            '                           value="dowiedzieć się więcej o wędkarstwie">' +                 // L1(value) wartość tego pola
            '                       <label for="checkbox_1">skorzystać z formularzy</label><br>' +      // L1(label) oraz ich etykiety
            '                       <input type="checkbox" name="goals" id="checkbox_2" ' +
            '                           value="zobaczyć statystyki">' +
            '                       <label for="checkbox_2">zobaczyć statystyku</label><br>' +
            '                       <input type="checkbox" name="goals" id="checkbox_3" value="mapa">' +
            '                       <label for="checkbox_3">mapa</label><br>' +
            '                </td>' +                                                                   // L1(td) koniec komurki tabeli
            '            </tr>' +                                                                       // L1(tr) koniec wiersza tabeli
            '        </tbody>' +                                                                        // L1(tbody) koniec ciała tabeli
            '        <tfoot>' +                                                                         // L1(tfoot) początek stopki tabeli (ma w sobie przyciski obługujące formularz)
            '            <tr>' +                                                                        // L1(tr) początek wierszu tabeli
            '                <td><input type="submit" value="Wyślij" name="Wyślij"></td>' +             // L1(submit) przycisk zatwierdzenia formularzu
            '                <td><input type="reset" value="Anuluj" name="Anuluj"></td>' +              // L1(reset) przycisk wyczyszczenia formularzu
            '            </tr>' +                                                                       // L1(tr) koniec wiersza tabeli
            '        </tfoot>' +                                                                        // L1(tfoot) koniec stopki tabeli
            '    </table>' +                                                                            // L1(table) koniec tabeli do wprowadzania danych
            '</form></fieldset>');                                                                      // L1(form,fieldset) koniec formularzu, fieldset i obzługi przycisku
        $("form").submit(function () {                          // L9(.submit) dodawanie obsługi przycisku "submit" formularzu: pokazanie odpowiedniego okienka do akceptacji przesłania danych

            // sekcja pobrania potrzebnych danych z pól formularza (dla łatwiejszego wykorzystania)
            let birthday = new Date($("#birthday").val());                      // L9(jQuery) pobieranie wartości z pola do wprowadzenia daty
            let telephone = $("#telephone").val();                              // L9(jQuery) pobieranie wartości z pola do wprowadzenia telefonu
            let email = $("#email").val();                                      // L9(jQuery) pobieranie wartości z pola do wprowadzenia email
            let types_of_fishing = $("#types_of_fishing option:selected");      // L9(jQuery) zmienna przechowująca dane ze wszystkich odznaczonych opcji z id=types_of_fishing (pole typu select)
            let source = $("input[name='source']:checked");                     // L9(jQuery) zmienna przechowująca dane ze wszystkich odznaczonych pól z name=source (pola typu radio)
            let goals = $("input[name='goals']:checked");                               // L9(jQuery) zmienna przechowująca dane ze wszystkich pól z name=goals (pola typu checkbox)
            console.log(goals);

            let message = "Następujące Dane zostaną wysłane:\n";        // L6(javascript) zmienna do przechowywania wyświetlanej wiadomości + przejście na nową linię
            message += "Nazwisko i imie: " + $("#lastname").val() + " " + $("#firstname").val() + "\n";     // L6(javascript), L9(jQuery) dodawanie informacji do wiadomości do wyświetlania; ->
                                                                                                            // -> są obowiązkowe więc nie musimy sprawdzać czy są + przejście na nową linię
            if (birthday) message += "Data urodzenia: " + ("0" + birthday.getDate()).slice(-2) + "." +      // L6(javascript) jeżeli pole jest niepuste, to dodaj (sformatowaną) informacje o dacie urodzenia: ->
                ("0" + birthday.getMonth()).slice(-2) + "." + birthday.getFullYear() + "\n";                // L6(javascript) do liczby daty i miesiąca dodaj '0' i odciń do dwuch znaków z prawej strony + przejście na nową linię
            if (telephone) message += "Telefon: " + telephone + "\n";                                       // L6(javascript) jeżeli pole jest niepuste, to dodaj (sformatowaną) informacje o numerze telefonu: + przejście na nową linię
            if (email) message += "Email: " + email + "\n";                                                 // L6(javascript) jeżeli pole jest niepuste, to dodaj (sformatowaną) informacje o dacie urodzenia: + przejście na nową linię
            message += "Doświadczenie wędkarskie: " + $("#experience").val() + "\n";                        // L6(javascript), L9(jQuery) dodawanie informacji do wiadomości do wyświetlania; ->
                                                                                                            // -> są obowiązkowe więc nie musimy sprawdzać czy są + przejście na nową linię
            if (types_of_fishing.length > 0) {                                                              // L6(javascript) jeżeli lista odznaczonych opcji z pola select jest niepusta
                message += "Preferowane rodzaje wędkarstwa: ";                                              //  L6(javascript)to dodaj info o tym do wiadomości
                for (let option of types_of_fishing) message += option.value + "; ";                        //  L6(javascript) przechodzimy po kolejnych odznaczonych polach i dodajemy to do wiadomości
                message += "\n";                                                                            //  L6(javascript)  + przejście na nową linię
            }

            if (source.length !== 0)                                                                        // L6(javascript) jeżeli jakiś z przycisków radio został odznaczony
                message += "W jaki sposób dowiedzieliście o tej stronie: " + source[0].value + "\n";        // L6(javascript) to dodaj info o tym do wiadomości + przejście na nową linię

            if (goals.length !== 0) {                                                                       // L6(javascript) jeżeli lista odznaczonych checkboxów jest niepusta
                message += "Jesteś na stronie by: ";                                                        // L6(javascript)to dodaj info o tym do wiadomości
                for (let goal of goals) if (goal.checked) message += goal.value + "; ";                     // L6(javascript) przechodzimy po kolejnych odznaczonych polach i dodajemy to do wiadomości
                message += "\n";                                                                            // L6(javascript)  + przejście na nową linię
            }

            alert(message);                                                                                 // L9(jQuery) pokazanie odpowiedniego okienka do akceptacji przesłania danych.
            return false;
        });
    });
});