/*
w tym skrypcie jest wykorzystywana wiedza z laboratoriów
    6 - javascript)
    8 - walidacja formularzy za pomocą js
    10 - localStorage)
*/

// sprawdzenie czy przeglądarka wspiera localStorage
function localStorageTest() {                                                   // kod ze strony https://kursjs.pl/kurs/storage/storage.php
    const test = "test" + new Date().valueOf();
    try {
        localStorage.setItem(test, test);
        localStorage.removeItem(test);
        return true;
    } catch (e) {
        return false;
    }
}

// koniec kodu ze strony https://kursjs.pl/kurs/storage/storage.php
function show_msg(field, text) {                                                // funkcja do wyświetlania komunikatu "text" w pole o id "field"
    document.getElementById(field).innerHTML = text;                            // L6(js, getElementById, innerHTML)
}

function clear_msgs() {                                                         // funkcja "czysccząca" wszystkie komunikaty
    show_msg("green", "&nbsp;");                                     // L1() wprowadzenie znaku pustego za pomocą encji
    show_msg("red", "&nbsp;");                                       // kolejne polecenie wprowadzajęce do pól puste linie
    show_msg("error_name", "");
    show_msg("error_date", "");
    show_msg("error_weigh", "");
    show_msg("error_type_of_fishing", "");
    show_msg("error_destiny", "");
    show_msg("error_weather", "");
}

function choice(a) {                                                            // funikcja odpowiedzialna za obślugiwanie przycisków
    if (localStorageTest()) {                                                   // jeżeli przeglądarka wspiera localStorage
        clear_msgs();                                                               // to 1) wyczyszcz komunikaty
        if (a === 4) show_all()                                                     // jeżeli został wciśnięty przycisk 4, to wywołaj funkcje wyświetlającą wszystkie zapisane rekordy
        else if (a === 5) delete_all()                                              // inaczej, jeżeli został wciśnięty przycisk 5, to wywołaj funkcje czyszczącą lokacStorage
        else if (validate_name()) {                                                 // inaczej jezeli nazwa ryby została wprowadzona poprawnie i
            if (a === 2) remove_record()                                // jeżeli został wciśnięty przycisk 2, to wywołaj funkcje zarządząjącą poszczególnymi rekordami z parametrem "remove"
            else if (a === 3) find_record();                                           // inaczej, jeżeli został wciśnięty przycisk 3, to wywołaj funkcje poszukującą rekordy o podanej nazwie
            else if (validate_record()) {                                              // inaczej jeżeli wszystkie pola formularzu zostały wprowadzone poprawnie i
                if (a === 0) manage_record("save");                                 // jeżeli został wciśnięty przycisk 0, to wywołaj funkcje zarządząjącą poszczególnymi rekordami z parametrem "save"
                else if (a === 1) manage_record("edit");                            // jeżeli został wciśnięty przycisk 1, to wywołaj funkcje zarządząjącą poszczególnymi rekordami z parametrem "edit"
            }
        } else show_msg("error_name", "Poprawnie wpisz nazwę ryby!");               // inaczej wyświetli komunikat o błednie wprowadzonej nazwie ryby
    } else {                                                                    // inaczej (jeżeli przeglągarka nie wspiera localStorage)
        document.getElementById("t_output").style.display = "table";       // pokaż tabele dla wyprowadzania rekordów
        document.getElementById('b_output').innerHTML =                    // wyświetl w jej komórkie komunikat o tym że przeglądarka nie wspiera localStorge
            '<tr><td>' + "Browser does not support localStorage" + '</td></tr>';
    }
    return false;
}

function validate_text(id, regex) {
    // funkcja sprawdza czy wartość wprowadzona do pola tekstowego o id pole_id
    // pasuje do wzorca zdefiniowanego za pomocą wyrażenia regularnego zawartego w obiektRegex
    return regex.test(document.getElementById(id).value);
}

function validate_radio(name_radio) {
    // funkcja sprawdza czy wybrano przycisk radio
    // z grupy przycisków o nazwie name_radio
    let object = document.getElementsByName(name_radio);
    for (let i = 0; i < object.length; i++)
        if (object[i].checked) return true;
    return false;
}

function validate_checkbox(checkbox_id) {
    // funkcja sprawdza czy przycisk typu checkbox
    // o identyfikatorze checkbox_id jest zaznaczony
    return document.getElementById(checkbox_id).checked;
}

function validate_name() {
    // funkcja sprawdza czy wartość wprowadzona do pola do wprowadzenia nazwy ryby (id name)
    // pasuje do wzorca zdefiniowanego za pomocą wyrażenia regularnego zdefiniowanego w polu regex funkcji validate_text
    // do podanego wyrażenia regularnego pasują ciągi znakowe od 2 do 20 symboli skłądające się z liter alfabetu łacińskiego, znaków polskich oraz znaku "-"
    return validate_text("name", /^[A-Za-ząęźżśóćńłĄĘŹŻŚÓĆŃŁ-]{2,20}$/);
}

function validate_record() {
    // funkcja sprawdza czy wartości wprowadzone do pól formularza są poprawnie wprowadzone

    // zmienna do przechowywanie stanu sprawdzenia formularza (ok === true => formularz jest wypełniony poprawnie)
    let ok = true;

    // sekcja pobrania potrzebnych danych z pól formularza (dla łatwiejszego wykorzystania)
    let name = document.getElementById("name").value;
    let date = document.getElementById("date").value;
    let weigh = document.getElementById("weigh").value;
    // zmienna przechowująca dane ze wszystkich pól z name=weather
    let weather = document.querySelectorAll("input[name='weather']");

    // zmienna pomocnicza, przechowująca liczbę odznaczonych checkboxów tego formularzu
    let checkbox_true = 0;

    // definicje odpowiednich wyrażeń regularnych dla sprawdzenia poprawności danych wprowadzonych do pól tekstowych
    // do wyrażenia regularnego sprzwdzającego poprawność wpisanej daty pasują daty od "01.01.1900" do "31.12.2021" (zamiast kroperk mogą być tez '/' oraz '-'
    let date_regex = /^(0?[1-9]|[12][0-9]|3[01])[\/\-\\.](0?[1-9]|1[012])[\/\-\\.](19[0-9][0-9]|20([01][0-9]|2[01]))$/
    // do wyrażenia regularnego sprzwdzającego poprawność wpisanej wagi ryby pasują liczby rzeczywiste w zakresie (0; 100) z rozdielaczami "." i ","
    let weigh_regex = /^(?=.+)(?:[1-9]\d?|0)?(?:[.,]\d+)?$/;

    //Sprawdzanie kolejnych pól formularza; w przypadku błędu - pojawia się odpowiedni komunikat w odpowiednim polu o id "error_*"

    if (name === "") show_msg("error_name", "Wpisz nazwę ryby");                // jeżeli do pola nic nie wprowadzono wyświetl odpowiedni komunikat
    else if (!validate_name()) {                                                          // inaczej, jeżeli wprawodzony ciąg NIE pasuję do wyrażenia regularnego (w tym przypadku regex jest wprowadzone w odpowiedniej funkcji)
        ok = false;                                                                           // odznaczamy, że formularz jest wypełniony źle
        show_msg("error_name", "Wpisz poprawnie nazwę ryby!");                     // oraz wyświetlamy odpowiedni komunikat o błędnie wprowadzonych danych
    }                                                                                     // inaczej nic nie rób ("domyślnie" wszystkie komunikaty są wyczyszczane)

    if (date === "") show_msg("error_date", "Wpisz datę!");                    // jeżeli do pola nic nie wprowadzono wyświetl odpowiedni komunikat
    else if (!validate_text("date", date_regex)) {                                    // inaczej, jeżeli wprowadzone dane nie pasują do  wyrażenia regularnego daty
        ok = false;                                                                           // odznaczamy, że formularz jest wypełniony źle
        show_msg("error_date", "Wpisz poprawnie datę!");                           // oraz wyświetlamy odpowiedni komunikat o błędnie wprowadzonych danych
    }                                                                                     // inaczej nic nie rób ("domyślnie" wszystkie komunikaty są wyczyszczane)

    if (weigh === "") show_msg("error_weigh", "Wpisz wagę!");                  // jeżeli do pola nic nie wprowadzono wyświetl odpowiedni komunikat
    else if (!validate_text("weigh", weigh_regex) || parseFloat(weigh) === 0) {       // inaczej, jeżeli wprowadzone dane nie pasują do  wyrażenia regularnego wagi lub wprowadzona wartość przekonwertowana na liżbę rzeczywistą jest równa 0
        ok = false;                                                                           // odznaczamy, że formularz jest wypełniony źle
        show_msg("error_weigh", "Wpisz poprawnie wagę!");                          // oraz wyświetlamy odpowiedni komunikat o błędnie wprowadzonych danych
    }                                                                                    // inaczej nic nie rób ("domyślnie" wszystkie komunikaty są wyczyszczane)

    if (!validate_radio("destiny")) {                                                                        // jezeli nie zostało odznaczone żadne z pól typu radio
        ok = false;                                                                           // odznaczamy, że formularz jest wypełniony źle
        show_msg("error_destiny", "Musisz wskazać sposób płatności!");              // oraz wyświetlamy odpowiedni komunikat o błędnie wprowadzonych danych
    }                                                                                   // inaczej nic nie rób ("domyślnie" wszystkie komunikaty są wyczyszczane)

    for (let i = 0; i < weather.length; i++) if (validate_checkbox(weather[i].id)) checkbox_true++; // zliczamy ilości odznachonych pól wyboru
    if (checkbox_true === 0) {                                                          // jezeli licznik odznaczonych pól jest równy 0
        ok = false;                                                                           // odznaczamy, że formularz jest wypełniony źle
        show_msg("error_weather", "Musisz wybrać pogodę!");                        // oraz wyświetlamy odpowiedni komunikat o błędnie wprowadzonych danych
    }                                                                                   // inaczej nic nie rób ("domyślnie" wszystkie komunikaty są wyczyszczane)

    return ok;                                                                          // zwracamy informacje o poprawności wypełnienia formularza
}

// funkcja zarządzająca rekordami - umożliwia wprowadzanie, edycję i usuwanie rekordów. jako parametr przyjmuję tryb pracy - save, edit i remove odpowednio
function manage_record(mode) {
    let list = JSON.parse(localStorage.getItem("list"));                            // pobieranie liste rekordów z localStorage
    if (list === null) list = [];                                                        // jeżeli nie istnieje - stwórz listę pustą

    let name = document.getElementById('name').value;                           // pobranie wartości z formularzu
    let date = document.getElementById('date').value;
    let weigh = document.getElementById('weigh').value;
    let type_of_fishing = document.getElementById('type_of_fishing').value;     // pole typu select przyjmuje wartość wybreanej opcji
    let destiny_list = document.getElementsByName('destiny');                // pobranie listy przycisków radio
    let weather_list = document.querySelectorAll("input[name='weather']");      // pobranie listy przycisków checkbox

    // zmienne do przechowywania odznaczonych przycisków typu rabio oraz checkbox odpowiednie
    let destiny = "";
    let weather = "";

    // wyszukiwanie odznaczonego przycisku typu radio
    for (let i = 0; i < destiny_list.length; i++)       // przechodzimy po kolejnych elementach listy przycisków radio
        if (destiny_list[i].checked === true) {         // jeżeli jest odznaczny
            destiny = destiny_list[i].value;                // wpisz wartość tego przecisku do zmiennej przechowującej dane o odznaczonym przycisku typu radio
            break;                                          // i przerwij działanie pętli
        }

    // wyszukiwanie odznaczonych przycisków typu checkbox
    for (let i = 0; i < weather_list.length; i++)       // przechodzimy po kolejnych elementach listy przycisków checkbox
        if (validate_checkbox(weather_list[i].id))      // jeżeli jest odznaczny
            weather += weather_list[i].value + "; ";        // dodaj wartość tego przecisku do zmiennej przechowującej dane o odznaczonym przycisku typu checkbox

    // tworzenie obiektu (rekordu) w formacie JSON z pobranych danych
    let item = {
        "name": name,
        "date": date,
        "weigh": weigh,
        "type_of_fishing": type_of_fishing,
        "destiny": destiny,
        "weather": weather
    };

    // zmienna do przechowywania indeksu rekordu w tabeli rekordów,
    // którego imię jest takie same jak imię utworzonego rekordu
    let position = 0;
    while (position < list.length) {                // przechodzimy po liście rekordów
        if (item.name === list[position].name)          // jeżeli nazwa nowo utworzonego rekordu jest taka sama jak nazwa kolejnego elementy tabeli rekordów
            break;                                          // to przerwij działanie pętli, znaleźliśmy element o takiej samej nazwie
        position++;                                     // inaczej zwiększ indeks
    }

    // jeżeli w talice nie ma rekordu o takiej nazwie jak u nowo utworzonego rekordu,
    // to zmienna position przyjmie wartość list.length

    //wybór działania w zależności od trybu
    if (mode === "save") {                                      // jeżeli wybraliśmy opcję "zapisz rekord"
        if (position === list.length) {                             // i jeżeli elementu o takiej samej nazwie nie istnieje, to
            list.push(item);                                            // 1) dodaj element do listy przechowującej tablicę rekordów,
            localStorage.setItem('list', JSON.stringify(list));         // 2) odnów tablicę rekordów w localStorage
            show_msg("green", "Dodano nowy rekord");         // 3) wyświetl komunikat o pomyślnym dodaniu nowego rekordu
        } else show_msg('error_name',
            "Rekord o podanej nazwie już istnieje");           // inaczej wuświetl info o tym, że rekord o podanej nazwie już istnieje
    } else {                                                    // inaczej, (jeżeli wybraliśmy opcję "wyedytuj rekord")
        if (position !== list.length) {                             // i jeżeli elementu o takiej samej nazwie istnieje, to
            list[position] = item;                                      // 1) "wyedetuj" rekord (wsztawiamy zamiast poprzedniego rekordu nowo utworzony)
            localStorage.setItem('list', JSON.stringify(list));         // 2) odnów tablicę rekordów w localStorage
            show_msg("green",
                "Rekord o podanej nazwie został zmieniony");       // 3) wyświetl komunikat o pomyślnym wyedytowaniu rekordu
        } else show_msg('error_name',
            "Rekord o podanej nazwie nie istnieje");           // inaczej wuświetl info o tym, że rekord o podanej nazwie nie istnieje
    }
}

// funkcja obsługujaca przycisk "usuń rekord"
function remove_record () {
    let list = JSON.parse(localStorage.getItem("list"));     // pobieranie liste rekordów z localStorage
    if (list.length > 0) {                                        // jeżeli tablica rekordów nie jest pusta
        let name = document.getElementById('name').value;    // zmienna przechowujca nazwę wprowadzonej ryby
        // zmienna do przechowywania indeksu rekordu
        // w tabeli rekordów, którego imię jest takie same
        // jak imię utworzonego rekordu
        let position = 0;
        while (position < list.length) {                // przechodzimy po liście rekordów
            if (name === list[position].name)               // jeżeli nazwa nowo utworzonego rekordu jest taka sama jak nazwa kolejnego elementy tabeli rekordów
                break;                                          // to przerwij działanie pętli, znaleźliśmy element o takiej samej nazwie
            position++;                                     // inaczej zwiększ indeks
        }
        if (position !== list.length) {                               // jeżeli elementu o takiej samej nazwie istnieje, to
            list.splice(position, 1);                                   // 1) usuń rekord o wyznaczonym indeksie
            if (list.length === 0) delete_all()                         // 2) sprawdź czy nie był to ostatni element tablicy; jeżeli tak, to wyczyszcz localStorage
            else localStorage.setItem('list', JSON.stringify(list));        // inaczej odnów tablicę rekordów w localStorage
            show_msg("green",
                "Rekord o podanej nazwie został usunięty");        // 3) wyświetl komunikat o pomyślnym usunięciu rekordu
        } else show_msg("error_name",
            "Nie znaleziono rekordu o podanej nazwie")          // inaczej wyświetl info o tym, że nie ma rekordu o podanej nazwie
    } else show_msg("error_name",
        "Baza jest pusta");                                 // inaczej wyświetl info o tym, że baza rekordó jest pusta
}

//funckcja obsługująca wyświetlanie rekordów w postaci tabeli;
// jako parametr przyjmuję listę rekordów (rekordy są w formacie JSON)
function show_records(list) {
    let s = "";                                                                         // zmienna do której będziemy dodawali kod HTML który później wyświetlimy w tabeli
    document.getElementById("t_output").style.display = "table";               // uwidoczniamy tabelę do której wyprowadzamy dane
    for (let i = 0; i < list.length; i++)                                               // dodajemy kod odpowiadający rekordom w wiersze tablicy do wyświetlania rekordów do odpowiedniej zmiennej
        s += '<tr><td>' + list[i].name + '</td><td>' + list[i].date + '</td>' +
            '<td>' + list[i].weigh + '</td><td>' + list[i].type_of_fishing + '</td>' +
            '<td>' + list[i].destiny + '</td><td>' + list[i].weather + '</td></tr>';
    document.getElementById('b_output').innerHTML = s;                         // wyświetlamy w ciele tabeli do wyprowaddzania danych otzymany kod HTTML (czyli rekordy sw postaci tabeli)
}

//funckcja obsługująca wyszukiwaniu rekordów o podanej nawie (lub chęści nazwy) oraz ich wyświetlanie
function find_record() {
    let list = JSON.parse(localStorage.getItem("list"));            // pobieranie liste rekordów z localStorage
    if (list !== null) {                                                     // jeżeli tablica rekordów nie jest pusta
        let to_find = document.getElementById('name').value;            // tworzymy zmienna do przechowywania nazwy (lub jej części) rekordu do wyszukiwania
        let found = [];                                                          // tworzymy tabelę do przechowyania znalezionych rekordów
        for (let i = 0; i < list.length; i++)                                    // przechodzimy po liście rekodów
            if (list[i].name.search(to_find) !== -1) found.push(list[i]);            // i jeżeli znaleźlismy rekord o podanej nazwe (lub jej części), to dodajemy go do odpowiedniej tablicy
        if (found.length === 0) show_msg("red",
            "Nie znaleziono rekordów o podanych parametrach")               // jeżeli tablica znalezionych rekorbów jest pusta, to wyświetli odpowiedni komunikat
        else {                                                                   // inaczej
            show_msg("green", "Wyniki wyszukiwania:");                    // wyświetl stosowny komunikat oraz
            show_records(found);                                                    // wyświetl wyszukane rekordy
        }
    } else show_msg("red", "Baza jest pusta");                    // inaczej wyświetli info o tym, że baza rekordów jest pusta i nie ma nic do wyświetlania
}

//funckcja obsługująca wyświetlanie wszystkich rekordów
function show_all() {
    let list = JSON.parse(localStorage.getItem("list"));            // pobieranie liste rekordów z localStorage
    if (list !== null) {                                                 // jeżeli tablica rekordów nie jest pusta
        show_msg("green", "Wyniki wyszukiwania:");                // wyświetl stosowny komunikat oraz
        show_records(list);                                                  // wyświetl wszystkir rekordy
    } else show_msg("red", "Baza jest pusta");                // inaczej wyświetl info o tym że baza rekordów jest pusta

}

//funckcja obsługująca usunięcie wszyystkich rekordów
function delete_all() {
    show_msg("green", "Wszystkie rekordy zostały usunięte");    // kominukat o pomyślnym wykonaniu zadania
    localStorage.clear();                                                 // czyszczenie localStorage
    document.getElementById("t_output").style.display = "none";  // chowamy tabelę do wyświetlana wyników
    document.getElementById('b_output').innerHTML = "";          // czyszczymy ciało tabeli do wyświetlana wyników
}